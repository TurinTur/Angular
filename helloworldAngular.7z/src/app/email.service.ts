import { Injectable } from '@angular/core';   // hace falta para inyectar dependencias en la clase

@Injectable({
  providedIn: 'root'
})
export class EmailService {

  constructor() { }
}
